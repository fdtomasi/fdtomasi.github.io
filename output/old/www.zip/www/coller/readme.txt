Thank you for Using Coller Wordpress Theme.

	i) Coller Wordpress Theme is Based on the Underscores Framework http://underscores.me/, (C) 2012-2013 Automattic, Inc. 
	ii) Coller has been created Rohit Tripathi. You can Follow me on http://github.com/rohitink.
	iv) It comes GNU General Public License v3. More Details about the License can be found in the license.txt file included in the theme.
	
## Copyrights for Resources used in this theme.

	i) Social icons located in the 'images' folder, are under GPL v2 License have been created by me. More details http://rohitink.com/sociocons/
	ii) This theme uses bxSlider, which is under the WTFPL License. More details: 
	        http://bxslider.com/faqs
	   		 http://www.wtfpl.net/about/
	iii) For the Administration Panel, we have used "Options Framework", which is under GPL v2 license. wptheming.com/options-framework-theme/
	iv) We have used 1 External font from Google Webfonts: LATO. which is under SIL Open Font License v1.1.
	iv) The files options-custom.js, color-picker.js and media-uploader.js present in the "/js" Folder are part of the "Options Framework", and are under GPL v2.
	v) custom.js has been created by me and under GPL v2.
	vi) skip-link-focus-fix.js, navigation.js, customizer.js & keyboard-image-navigation.js are part of the Underscores Framework used by the theme, and hence under GPL v2.
	vii) The Images divider.png, replied.png, quote.png, nthumb.png & menu.png have been created by me and are under GPL v2. 
	ix) The image used in Screenshot is under Public Domain CC0 by unsplash.com
	
Everything else used in this theme has been created by me, especially for Coller theme and is distributed under GPLv3 license.
	